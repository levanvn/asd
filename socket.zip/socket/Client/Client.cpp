#include "ClientHeader.h"

#include <iostream>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <unistd.h>
using namespace std;

void User::SignUp(){
    cout << "-------Dien cac thong tin de dang ky!-------" << endl;
    username = new char[10];
    city = new (char);
    password = new char;
	extern int sockfd;
	cout << "Nhap vao username: ";
	char user[20],pass[20],ci;
	cin >> user;
	//fgets(username);
	 write(sockfd,user, sizeof(user ));
	cout << "Nhap password: ";
	cin >> password;
	//password = sha1(password);
    //cout << password;
	cout << "Enter city: ";
	cin >> city;
	
	 //send(sockfd, username, 10,0);
	int size;
	cout <<&username << "  " << username << "  " <<*username<<"  " << sizeof(*username) << endl;
	
	 //cout << sizeof(user) << "write: " << size;
	//cout << "  " << sockfd << endl; 
	send(sockfd, password, sizeof(password),0);
	send(sockfd, city, sizeof(city),0);
	char s[100];
	recv(sockfd,s, sizeof(s),0);
	cout << s;

}
